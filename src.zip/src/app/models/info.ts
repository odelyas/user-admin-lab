export  class info{
    public firstName: string;
    public   lastName: string;
    public   jobTitle: string;
    public   avatar: string;
    public  phoneNumber: string;
    }